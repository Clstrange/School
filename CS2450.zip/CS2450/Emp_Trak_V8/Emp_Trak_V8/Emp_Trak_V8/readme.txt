Payroll - How it works CURRENTLY
    When you enter the payroll page, you have 5 functioning payroll buttons on
    the screen. You may choose to add an receipt for those who are on commissioned
    rate, and you may add a single timecard for an employee who is on hourly.

    When you want to run the payroll, you have a few options. You may just run
    the payroll which will just calculate the pay roll for individuals who 
    have any connection to salary. This includes commissioned people without
    their pay receipts checked in. To get the Salary and Commissioned payroll,
    click Process Receipts, then click run payroll. To get the all of the 
    payroll(recommended), click process receipts, then click process timecards, 
    then click run payroll. This will reset the timecards and receipts that have
    been processed in the program.

    After the payroll has been run, the text file that is output goes into the 
    output folder as paylog.txt.

Starting up program - Download latest version of python, in the command line, get to the root folder
of EMP_TRACK_V5, copy the path from where ever you saved it and paste it into the command line, and 
type python main.py

Back-up plan for starting up the program - attempt to run it from thonny using python 3.7.9
DO NOT use VS Code
