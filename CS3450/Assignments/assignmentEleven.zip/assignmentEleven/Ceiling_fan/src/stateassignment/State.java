package stateassignment;

public interface State {
    public void pull();
}
