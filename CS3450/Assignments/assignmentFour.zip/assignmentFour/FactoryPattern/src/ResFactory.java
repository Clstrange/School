public interface ResFactory {
    public void PrintDocument();
    public void DrawWidget();
}
