public interface Document {
    public void PrintDocument();
    
}
