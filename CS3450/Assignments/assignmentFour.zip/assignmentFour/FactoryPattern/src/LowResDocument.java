public class LowResDocument implements Document {

    @Override
    public void PrintDocument() {
        System.out.println("Printing a low resolution document...");
    }
    
}
