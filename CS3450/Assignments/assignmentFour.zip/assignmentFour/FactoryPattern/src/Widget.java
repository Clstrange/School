public interface Widget {
    public void DrawWidget();
}
