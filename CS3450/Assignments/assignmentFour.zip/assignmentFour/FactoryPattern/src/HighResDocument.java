public class HighResDocument implements Document {

    @Override
    public void PrintDocument() {
        System.out.println("Printing a high resolution document...");
    }
    
}
