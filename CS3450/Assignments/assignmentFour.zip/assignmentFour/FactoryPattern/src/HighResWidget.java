public class HighResWidget implements Widget {

    @Override
    public void DrawWidget() {
        System.out.println("Drawing a high resolution widget...");
    }
    
}
