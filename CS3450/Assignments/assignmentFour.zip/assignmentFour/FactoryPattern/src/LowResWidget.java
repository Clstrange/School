public class LowResWidget implements Widget {

    @Override
    public void DrawWidget() {
        System.out.println("Drawing a low resolution widget...");
    }
    
}
