package creditcard;

public abstract class Customer {
    protected abstract String getNumber();
    protected abstract int getMonth();
    protected abstract int getYear();
}
