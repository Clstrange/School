package learningActivity;
/*
Car master class
L. Thackeray
*/
public abstract class CarClass 
{
    private double engineSize = 345;
    private int wheels = 4;
    private int cylinders = 8;    
    private String driverType = "none";
    private String carNotes = "none";
    
    public double getEngine()
    {
        return engineSize;        
    }
    
    public double getWheels()
    {
        return wheels;        
    }
    
    public double getCylinders()
    {
        return cylinders;        
    }    
    
    public String getDriverType()
    {
       return driverType;
    }
    public String getCarNotes()
    {
        return carNotes;

    }
}


