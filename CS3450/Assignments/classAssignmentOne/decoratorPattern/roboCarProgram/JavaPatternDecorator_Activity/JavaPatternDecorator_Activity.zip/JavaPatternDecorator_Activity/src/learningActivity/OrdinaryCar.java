package learningActivity;


public final class OrdinaryCar extends CarClass
{
    //override base class state
    private String driverType = "Human.";
    private String carNotes = "Ordinary commuter car. I bought this new in 2004";

    public OrdinaryCar()
    {

    }      
                
    @Override      
    public String getDriverType()
    {
        return driverType;
    }

     
    
        @Override
    public String getCarNotes()
    {
        return carNotes;
    }
}
