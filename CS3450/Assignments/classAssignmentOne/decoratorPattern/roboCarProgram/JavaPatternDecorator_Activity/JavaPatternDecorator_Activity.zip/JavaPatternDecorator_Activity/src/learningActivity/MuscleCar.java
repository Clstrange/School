/**
 *
 * @author L. Thackeray
 * my kind of car
 */
    
package learningActivity;


public final class MuscleCar extends CarClass
{
    private String driverType = "Brave Person.";
    private String carNotes = "Street Monster. I built it up from scratch\nRide free, die hard";
    private double engineSize  = 489;

    public MuscleCar()
    {

    }      
                
    @Override      
    public String getDriverType()
    {
        return driverType;
    }
    @Override
    public double getEngine()
    {
       return engineSize;
        
    }
    @Override
    public String getCarNotes()
    {
        return carNotes;
    }
}

