package learningActivity;


public final class OrdinaryCompact extends CarClass
{
    //override base class state
    private String driverType = "Small Human.";
    private String carNotes = "I am compact, but I am small, but peppy!";   
    private double engineSize  = 189;  
    
    public OrdinaryCompact()
    {

    }
    
    @Override
    public double getEngine()
    {
       return engineSize;
        
    }
    
    @Override
    public String getDriverType()
    {
        return driverType;
    }

    @Override
    public String getCarNotes()
    {
        return carNotes;
    }
}


