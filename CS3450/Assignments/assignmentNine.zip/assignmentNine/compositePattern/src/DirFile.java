public class DirFile extends Component{

    public DirFile(String name) {
        super(name);
    }
    
}
