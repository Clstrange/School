interface DisplayElement {
    public void display();
}
