interface Observer {
    public void update();
    
}
