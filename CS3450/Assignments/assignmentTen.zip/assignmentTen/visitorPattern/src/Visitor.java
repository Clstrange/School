public interface Visitor {
    public void visit(DirFile dirFile);
    public void visit(Folder folder);
}
