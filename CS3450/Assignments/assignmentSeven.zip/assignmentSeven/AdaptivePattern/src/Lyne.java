public class Lyne extends Shape {
    @Override
    void display() {
        System.out.println("Displaying a Line");
    }

    @Override
    void fill() {
        System.out.println("Filling a Line");
    }

    @Override
    void undisplay() {
        System.out.println("Undisplaying a Line");
    }
    
}
