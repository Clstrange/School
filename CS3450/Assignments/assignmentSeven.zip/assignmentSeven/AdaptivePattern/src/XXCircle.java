public class XXCircle {
    public void setLocation() {
        System.out.println("Set the Circle's location");
    }

    public String getLocation() {
        return ("'Circle's Location'");
    }

    public void setItsColor() {
        System.out.println("Set the Circle's color");
    }

    public void displayIt() {
        System.out.println("Display a Circle");
    }

    public void fillIt() {
        System.out.println("Fill a Circle");
    }

    public void undisplayIt() {
        System.out.println("Undisplay a Circle");
    }

}
