public abstract class OutputDecorator implements Output {
}
