public interface Output {
    void write(Object o);
}

