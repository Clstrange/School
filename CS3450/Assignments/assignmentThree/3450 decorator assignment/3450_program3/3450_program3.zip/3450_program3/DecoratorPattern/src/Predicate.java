public interface Predicate {
    public boolean execute(Object o);
}
