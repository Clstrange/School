// represents a fan with settings speed settings (states) of
// low, medium, high, and off.
// by pulling the fan chain you can cycle through these settings


package proxyassignment;

public class Client {
    public static void main(String[] args) {
        
        }

}