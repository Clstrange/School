/*
 * Singleton demo
 * client
 * L. Thackeray
 */
package edu.uvu.cs;

/**
 *
 * @author lthackeray
 */
public class SingltonInsurance {

 
    public static void main(String[] args) {
      
        Policy myPolicy = new Policy();
        String insuredName = myPolicy.GetInsured();
        String insuredID = myPolicy.GetInsuredID();
        
        System.out.println(insuredName);
        System.out.println(insuredID);
        
        
                
        
        
    }
    
}
