/*
 * demonstration of singleton pattern
 * Insurance policy class
 * L. Thackeray
 */
package edu.uvu.cs;

/**
 *
 * @author lthackeray
 */
public class Policy {
    // hard coded data (this would normally come from stream or DB
    private int ID = 378591546;
    private String Insured = "Mike Fillmore";
    
    //getter for insured name
    public String GetInsured(){
        
        return Insured;
    }
    
    //getter for insured ID
    public String GetInsuredID() {
        
        return Integer.toString(ID);    
    
    }
    
}
