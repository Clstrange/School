

const stateAbbreviations = [
    'AL','AK','AS','AZ','AR','CA','CO','CT','DE','DC','FM','FL','GA',
    'GU','HI','ID','IL','IN','IA','KS','KY','LA','ME','MH','MD','MA',
    'MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND',
    'MP','OH','OK','OR','PW','PA','PR','RI','SC','SD','TN','TX','UT',
    'VT','VI','VA','WA','WV','WI','WY'
   ];

function initValidation(formName) {

    let $form = $(formName)
    $(":input").change(function(ev){
        validateForm()
        if(!this.checkValidity()) {
            $(this).addClass("was-validated")
        }
    })

    $form.submit(function(event) {
        $form = $(this)
        formEl = $form.get(0)

        if(!formEl.checkValidity()) {
            $(":input").addClass("was-validated")
        }
        else {

            $("form").attr('hidden', 'hidden')
            $(".successMsg").show()
        }

        event.preventDefault()
        event.stopPropagation()
    })

function validateForm(){
    validateState("#state", "You must enter a valid two character stte code, e.g., UT")

    validateCheckboxGroup("#newspaper", "find-page", "Please select at least on of the following options")


}

function validateCheckboxGroup(fieldName, groupName, message) {
    let valid = false
    setElementValidity(fieldName, valid, message)
    return valid
}

function setElementValidity(fieldName, valid, message){
    let $field = $(fieldName)
    let el = $field.get(0)
    if (valid) {
        el.setCustomValidity(" ")
    } else {
        el.setCustomValidity(message)
    }
}


}