#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
int total_size = 0;
void do_ls(char [], int tab_count);
int isDir(const char* fileName);
int main(int ac, char *av[]) {
	if (ac == 1) {
		do_ls(".", 0);
	}
	else {
		do_ls(av[1],0);
	}
	printf("\nTotal file space used:%d\n", total_size);
}

int isDir(const char* fileName) {
	struct stat path;
	stat(fileName, &path);
	return S_ISREG(path.st_mode);
}

void do_ls(char dirname[], int tab_count) {
	DIR *dir_ptr;
	struct dirent *direntp;
	struct stat info;
	char test[50] = "..";
	if ((dir_ptr = opendir(dirname)) == NULL) {
		fprintf(stderr, "ls01: cannot open %s\n", dirname);
	}
	else {
		for (int i = 0; i < tab_count; i++) {
			printf("   ");
		}
		printf("DIR %s\n", dirname);
		while ((direntp = readdir(dir_ptr)) != NULL) {
			stat(direntp->d_name, &info);
			int ret = isDir(direntp->d_name);
			if (ret == 0) {
				if (*direntp->d_name != *test){
					do_ls(direntp->d_name, tab_count+1);
				}
			}
			else {
				for (int i = 0; i < tab_count+1; i++) {
					printf("   ");
				}
				printf("%d %s\n", (int)info.st_size, direntp->d_name);
				total_size += (int)info.st_size;

			}
		}
		closedir(dir_ptr);
	}
}

