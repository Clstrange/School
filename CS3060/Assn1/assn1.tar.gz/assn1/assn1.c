/* Cody Strange
 * CS3060-001 Fall 2022
 * Assn1
 *
 * Promis of Originality I promise that this source code file has, in it's entirety, been written by myself and by no other person or persons. If at any time an exacct copy of this source code is found to be used by another person in this term, I understand that both myself and the student that submitted the copy will receive a zero on this assignment.
*
*/

#include <stdio.h>

int main(int argc, char *argv[]) {
	printf("%s\n", "Assignment 1 by Jingpeng Tang");
	for (int i = 0; i < argc; i++) {
		printf("%s", "Argument #");
		printf("%d", i);
		printf("%s", ":");
		printf("%s\n",  argv[i]);
	}
	printf("%s", "Number of arguments printed:");
	printf("%d", argc);
	printf("%s\n", "");
	return 0;
}
