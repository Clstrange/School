#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {

	pid_t pid;
	pid = fork();
	char strOne[] = "/bin/";
	char *strTwo = argv[1];
	char *test[50];
	
    	for(int i = 0; i < argc - 1; i++) {
		test[i] = argv[i+1];
	}	

	if (pid != 0) {
		for (int i = 0; i < argc; i++){
			printf("%s ", argv[i]);
		}
		printf("%s\n", "");
		printf("%s", "Parent started, now waiting for process ID#");
		printf("%d", pid);
		printf("%s\n", "");
		wait(NULL);
		printf("%s\n", "PARENT resumed. Child exit code of 0. Now terminating parent");
	}
	if (argc == 2 && pid == 0) {
		strcat(strOne, strTwo);
		printf("%s\n", "CHILD started. One argument provided. Calling execvp(), never to return (sniff)");
		execlp(strOne,"ls",NULL);
		printf("%s", argv[1]);
	}
	else if (argc == 1 && pid == 0) {
		printf("%s\n", "CHILD started. No arguements provided. Terminating child.");
	}
	else if ((argc > 2)&&(pid == 0)) {
		strcat(strOne, strTwo);
		printf("%s\n", "CHILD started. More than one arguement provided. Calling execvp(), never to return (sniff)");
		execvp(strOne, test);

	}



}
