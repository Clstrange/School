#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
void *primeFactor(void *param);;

int main(int argc, char *argv[]) {
	int* returnValue;

	pthread_t tid[argc];
	pthread_attr_t attr;

	pthread_attr_init(&attr);

	for(int i = 0; i < argc-1; i++) {

	
		pthread_create(&tid[i],&attr,primeFactor,argv[i+1]);
	}

	for(int i = 0; i < argc-1; i++) {
		pthread_join(tid[i], (void**) &returnValue);

		printf("%d: ", atoi( argv[i + 1]));
		for (int j = 1; j < returnValue[0]; j++) {
			printf("%d ",(returnValue[j]));
		}
		printf("%s\n", "");

	}
}

void* primeFactor(void* param) {

	int primeNum[100];
	int iter = 1;
	int num = atoi(param);
	while (num%2 == 0) {
		primeNum[iter] = 2;
		iter++;
		num = num / 2;
	}

	

	for (int i = 3; i <= sqrt(num); i = i + 2) {
		while (num%i == 0){
			primeNum[iter] = i;
			iter++; 
			num=num/i;
		}
	}

	if (num > 2) {

		primeNum[iter] = num;
		iter++;
	}

	primeNum[0] = iter;
	
	

	int*  result = malloc(5 * sizeof(*result));
	result = primeNum;
	memcpy(result, primeNum, sizeof(int) * iter);
	return  result;
	
}
