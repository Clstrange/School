#include <stdbool.h>

struct process {
	int arrival_time;
	int burst_time;
	int process_id;
        int begin_waiting;
	int end_waiting;
	bool arriving;	
};
void init(struct process *p, int id, int at, int bt);
void start_waiting(struct process *p, int val);
void stop_waiting(struct process *p, int val);
int waiting_time(struct process *p);
bool get_arriving(struct process *p);
void set_arriving(struct process *p);
int get_arrival_time(struct process *p);
int get_burst_time(struct process *p);
int get_process_id(struct process *p);
void set_remaining_burst(struct process *p, int val);
