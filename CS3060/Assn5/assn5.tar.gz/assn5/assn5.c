#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "queue.h"


int main(int argc, char *argv[]) {
	FILE *in = fopen("test.txt", "r");	
	char buffer[100];
	int avg_response[100];
	int response_count = 0;
	int avg_waiting[100];
	int waiting_count = 0;	
	struct process *CPU_process = malloc(sizeof(*CPU_process));
	int process_id = 1;
	int arrival_time;
	int burst_time;
	int CPU_counter;
	struct process *next_process = malloc(sizeof(*next_process));
	struct process *start  = malloc(sizeof(*start));
	int queue_size;

	

	struct queue *job_queue = malloc(sizeof(*job_queue));
	struct queue *ready_queue = malloc(sizeof(*job_queue));
	queue_init(job_queue);
	queue_init(ready_queue);

	//loading the job queue
	init(start, 0, 0, 999999);
	queue_push(job_queue, start);	
	int ch = fscanf(in,"%s",buffer);
	while (ch != EOF) {
		arrival_time = atoi(buffer);
		fscanf(in,"%s",buffer);	
		burst_time = atoi(buffer);
		struct process *p = malloc(sizeof(*p));
		init(p, process_id, arrival_time, burst_time);
		queue_push(job_queue, p);
		process_id++;	
		ch = fscanf(in,"%s",buffer);	
	}
	CPU_process = queue_pop(job_queue);
	CPU_counter = 0;
	start_waiting(CPU_process, CPU_counter);
	printf("%d\n", get_count(job_queue));
	queue_size = get_count(job_queue);
	for (int i = 0; i < queue_size; i++) {
		if (get_arrival_time(get_top(job_queue)) - CPU_counter <= get_burst_time(CPU_process)){
			next_process = queue_pop(job_queue);
			printf("ID: %d\n", get_process_id(next_process));
			queue_push(ready_queue, next_process);
			start_waiting(next_process, CPU_counter);
			if (get_process_id(CPU_process)==0) {
			printf("test1\n");
			} else{
			set_remaining_burst(CPU_process, get_arrival_time(get_top(job_queue)) - CPU_counter);
			CPU_counter += get_arrival_time(get_top(job_queue)) - CPU_counter;
			}
		}else {
			printf("PID: %d\n",get_process_id(CPU_process));
			if (get_process_id(CPU_process)==0) {
			printf("test2\n");
			} else{


			stop_waiting(CPU_process, CPU_counter);
			if (get_arriving(CPU_process) == false) {
				printf("waiting_time: %d\n", waiting_time(CPU_process));
				avg_response[response_count] = waiting_time(CPU_process);
				response_count++;
			}
			avg_waiting[waiting_count] = waiting_time(CPU_process);
			waiting_count++;
			CPU_counter += get_burst_time(CPU_process);
			}
			CPU_process = queue_pop(ready_queue);
		}

      }

	for (int i = 0; i < waiting_count; i++) {
		printf("%d\n", avg_waiting[i]);

	}
	printf("a response time:%d\n", avg_response[1]);
	fclose(in);
}
