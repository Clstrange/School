#include "process.h"
#include <pthread.h>
#define BUFFER_SIZE (100)

struct queue {
	struct process *buffer[BUFFER_SIZE];
	int count;
	int in;
	int out;
};
void queue_init(struct queue *q);
struct process *queue_pop(struct queue *q);
void queue_push(struct queue *q, struct process *val);
struct process *get_top(struct queue *q);
int get_count(struct queue *q);
