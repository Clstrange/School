#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
	int* test_list[10] = {0};
	if(test_list[1] ==  NULL){
		*test_list[0] = 10;
		printf("%ls\n", test_list[0]);
	}
}
