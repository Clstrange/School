#include "process.h"
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void init(struct process *p, int id, int at, int bt) {
	p->process_id = id;
	p->arriving = false;
	p->arrival_time = at;
	p->burst_time = bt;	
}

void start_waiting(struct process *p, int val) {
	p->begin_waiting = val;
}

void stop_waiting(struct process *p, int val) {
	p->end_waiting = val;
}

int waiting_time(struct process *p) {
	return p->end_waiting - p->begin_waiting;
}

bool get_arriving(struct process *p) {
	return p->arriving;
}

void set_arriving(struct process *p) {
	p->arriving = true;
}

int get_arrival_time(struct process *p) {
	return p->arrival_time;
}

int get_burst_time(struct process *p) {
	return p->burst_time;
}

int get_process_id(struct process *p) {
	return p->process_id;
}

void set_remaining_burst(struct process *p, int val){
	p->burst_time -= val;
}
