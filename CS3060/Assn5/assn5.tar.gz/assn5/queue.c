#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

void queue_init(struct queue *q) {
	q->count = 0;
	q->in = 0;
	q->out = 0;
}

void queue_push(struct queue *q, struct process *val) {
	if (q->count == 100) {
		printf("Too many Processes, queue is full!");
	}
	q->buffer[q->in] = val;
	q->in = (q->in +1) % BUFFER_SIZE;
	q->count++;
}

struct process *queue_pop(struct queue *q){
	struct process *result = q->buffer[q->out];
	q->out = (q->out + 1) % BUFFER_SIZE;
	q->count--;
	return result;
	
}
struct process *get_top(struct queue *q) {
	return q->buffer[q->out];
}

int get_count (struct queue *q) {
	return q->count;
}
