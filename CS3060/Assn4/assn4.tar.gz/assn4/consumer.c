#include "prodcons.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void *consumer(void* buffer2) {
	int primeFactor;
	while(true) {
		primeFactor = pc_pop(buffer2);
		if (primeFactor == 0) {
			break;
		}
		printf("%d: ", primeFactor);
		while(true) {
			primeFactor = pc_pop(buffer2);
			if (primeFactor == -1) {
				break;
			}
			printf("%d ", primeFactor);
		}
		printf("\n");
	}
	pthread_exit(NULL);
}

