#include<stdio.h>

void* factor2pc(void* buffer);
