#include "prodcons.h"
#include "consumer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

void* factor2pc(void *buffer){
	struct prodcons buffer2[1];
	pc_init(buffer2);
	pthread_t tid2;
	pthread_attr_t attr2;
	pthread_attr_init(&attr2);
	pthread_create(&tid2,&attr2,consumer,&buffer2);
	int numToFactor;
	while (true) {
	        numToFactor = pc_pop(buffer);
	//	printf("[%d]", numToFactor);
		pc_push(buffer2, numToFactor);
		if (numToFactor == 0) {
			break;
		}	
		int primeNum[100];
		int iter = 0;
		while (numToFactor %2 == 0) {
			primeNum[iter] = 2;
			iter++;
			numToFactor = numToFactor / 2;
		}

		for (int i = 3; i <= sqrt(numToFactor); i = i + 2) {
			while (numToFactor%i == 0) {
				primeNum[iter] = i;
				iter++;
				numToFactor=numToFactor/i;
			}
		}
		
		if (numToFactor > 2) {
			primeNum[iter] = numToFactor;
			iter++;
		}		
	//	pc_push(buffer2, numToFactor);
		for (int i = 0; i < iter; i++) {
	//		printf("{%d}", primeNum[i]);
			pc_push(buffer2, primeNum[i]);
		}
	//	printf("|%d|", -1);
		pc_push(buffer2, -1);
	}
//	printf("|%d|", 0);
	pc_push(buffer2, 0);
	pthread_join(tid2, NULL);
	pthread_exit(NULL);
}

