#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include "prodcons.h"
#include <stdbool.h>

void pc_init(struct prodcons *pc) {
	pc->in = 0;
	pc->count = 0;
	pc->out = 0;
	pthread_mutex_init(&pc->count_lock, NULL);
};

void pc_push(struct prodcons *pc, int val) {
	while (pc->count == BUFFER_SIZE);
	pc->buffer[pc->in] = val;
	pc->in = (pc->in + 1) % BUFFER_SIZE;
	pthread_mutex_lock(&pc->count_lock);
	pc->count++;
	pthread_mutex_unlock(&pc->count_lock);
};



int pc_pop(struct prodcons *pc) {
	while (pc->count == 0);
	int result = pc->buffer[pc->out];
	pc->out = (pc->out + 1) % BUFFER_SIZE;
	pthread_mutex_lock(&pc->count_lock);
	pc->count--;
	pthread_mutex_unlock(&pc->count_lock);
	return result;
};



