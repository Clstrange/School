void *consumer(void *buffer2);

