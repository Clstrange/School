#include "prodcons.h"
#include "producer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
	struct prodcons buffer[1];
	pc_init(buffer);
	pthread_t tid;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_create(&tid,&attr,factor2pc,&buffer);	// producer thread
	for (int i = 1; i < argc; i++) {	
		pc_push(buffer, atoi(argv[i]));	
	}
	pc_push(buffer, 0);

	pthread_join(tid, NULL); // producer thread
}


