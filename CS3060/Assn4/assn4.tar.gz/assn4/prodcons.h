#include<pthread.h>
#include <stdbool.h>
#define BUFFER_SIZE (50)

struct prodcons {
	int buffer[BUFFER_SIZE];
	int count;
	int in;
	int out;
	pthread_mutex_t count_lock;
};
void pc_init(struct prodcons *pc);
int pc_pop(struct prodcons *pc);
void pc_push(struct prodcons *pc, int val);


