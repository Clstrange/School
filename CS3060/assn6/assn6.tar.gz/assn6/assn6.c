#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[]) {
	if (argc < 2) {
		fprintf(stderr, "Usage: %s <hex logical addr>\n", argv[0]);
		return -1;
	}

	unsigned long int value = strtoul(argv[1], NULL, 16);

	fprintf(stdout, "Logical Addr:0x%08lX - Page Index:0x%08lX - Offset:0x%08lX\n", value, value >> 12, value & ((1 << 12) - 1));

	return 0;
	
}
